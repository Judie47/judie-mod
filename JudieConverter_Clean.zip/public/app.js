var lastLogText = '';

// --- Language Setup for Script ---
const SCRIPT_TRANSLATIONS = {
    'de': {
        taskSubmitSuccess: "Aufgabe erfolgreich übermittelt, ID: ",
        taskSubmitError: "Fehler beim Übermitteln der Aufgabe: ",
        taskSubmitFail: "Übermittlung der Aufgabe fehlgeschlagen",
        conversionSuccessPrefix: "Konvertierung erfolgreich: ",
        taskQueryError: "Fehler bei der Abfrage der Aufgabe: ",
        taskQueryFail: "Abfrage der Aufgabe fehlgeschlagen",
        fileConversionErrorTitle: "Datei kann nicht konvertiert werden",
        ddosWarningHtml: "Aufgrund des Cloudflare DDoS-Schutzes kann der Konverter Dateien nicht automatisch herunterladen. Sie müssen die Mod-Dateien manuell herunterladen und das ZIP/RAR-Archiv hochladen.",
        fileTooLargeError: "Die Dateigröße überschreitet 300 MB und kann nicht konvertiert werden.",
        fileEmptyError: "Die Dateigröße ist 0, Konvertierung nicht möglich.",
        uploadingFileProgress: "Datei wird hochgeladen: ",
        fileUploadFail: "Datei-Upload fehlgeschlagen",
        fileUploadFailTryAgain: "Datei-Upload fehlgeschlagen, bitte versuchen Sie es später noch einmal.",
        dragDropPrompt: "oder ziehen Sie eine Datei hierher, um sie hochzuladen" 
    },
    'en': {
        taskSubmitSuccess: "Task submitted successfully, ID: ",
        taskSubmitError: "Error submitting task: ",
        taskSubmitFail: "Task submission failed",
        conversionSuccessPrefix: "Conversion successful: ",
        taskQueryError: "Error querying task: ",
        taskQueryFail: "Task query failed",
        fileConversionErrorTitle: "Cannot Convert File",
        ddosWarningHtml: "Due to Cloudflare DDoS protection, this will prevent the converter from automatically downloading files — this is not a problem with the converter itself. You need to manually download the mod files from their website and then upload the unextracted ZIP/RAR archive to the converter.",
        fileTooLargeError: "File size exceeds 300MB, cannot convert.",
        fileEmptyError: "File size is 0, cannot convert.",
        uploadingFileProgress: "Uploading file: ",
        fileUploadFail: "File upload failed",
        fileUploadFailTryAgain: "File upload failed, please try again later.",
        dragDropPrompt: "or drag and drop a file here to upload"
    }
};

// Language detection must be sync with the Go router's logic
let currentScriptLang = 'en';
if (window.location.pathname.includes('_de.html')) {
    currentScriptLang = 'de';
}

function _S(key) { 
    return SCRIPT_TRANSLATIONS[currentScriptLang][key] || SCRIPT_TRANSLATIONS['de'][key]; 
}
// --- End Language Setup for Script ---


$(document).ready(function() {
    // Theme switcher logic (unchanged)
    const themeSwitcher = $('.theme-switcher');
    const currentTheme = localStorage.getItem('theme') || 'light';
    
    $('body').attr('data-theme', currentTheme);
    themeSwitcher.html(currentTheme === 'dark' ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>');
    
    themeSwitcher.on('click', function() {
        const currentTheme = $('body').attr('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        $('body').attr('data-theme', newTheme);
        themeSwitcher.html(newTheme === 'dark' ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>');
        localStorage.setItem('theme', newTheme);
        
        const swalDarkCss = 'https://cfdx.zerodream.net/js/sweetalert2/dark.css';
        if (newTheme === 'dark') {
            $('head').append(`<link rel="stylesheet" href="${swalDarkCss}" id="swal-dark-theme">`);
        } else {
            $('#swal-dark-theme').remove();
        }
    });
    
    if (currentTheme === 'dark') {
        const swalDarkCss = 'https://cfdx.zerodream.net/js/sweetalert2/dark.css';
        $('head').append(`<link rel="stylesheet" href="${swalDarkCss}" id="swal-dark-theme">`);
    }
    
    const uuid = localStorage.getItem("convertUid");
    if (uuid) {
        startConversionMonitor(uuid);
    }

    $('.language-switcher').on('click', function() {
        const currentPath = window.location.pathname;
        if (currentPath.endsWith('_de.html')) {
            window.location.href = currentPath.replace('_de.html', '.html');
        } else {
            if (currentPath.endsWith('.html')) {
                window.location.href = currentPath.replace('.html', '_de.html');
            } else {
                window.location.href = currentPath + (currentPath.endsWith('/') ? '' : '/') + 'index_de.html';
            }
        }
    });

    // --- Drag and Drop Setup ---
    const dropZone = $('.drag-zone'); 
    const uploadButton = $('.upload-btn');
    if ($('#drag-drop-prompt').length === 0) { 
        // uploadButton.after(`<span class="text-muted ms-2 d-none d-md-inline" id="drag-drop-prompt">${_S('dragDropPrompt')}</span>`);
    }


    dropZone.on('dragenter dragover', function(event) {
        event.preventDefault();
        event.stopPropagation();
        $(this).addClass('drag-over-active');
        $('.main-container').addClass('drag-over-active'); 
    });

    dropZone.on('dragleave dragend', function(event) {
        event.preventDefault();
        event.stopPropagation();
        $(this).removeClass('drag-over-active');
        $('.main-container').removeClass('drag-over-active');
    });

    dropZone.on('drop', function(event) {
        event.preventDefault();
        event.stopPropagation();
        $(this).removeClass('drag-over-active');
        $('.main-container').removeClass('drag-over-active');

        const files = event.originalEvent.dataTransfer.files;
        if (files.length > 0) {
            const fileInputMock = { files: files };
            uploadFile(fileInputMock);
        }
    });
    // --- End Drag and Drop Setup ---
});

function println(text) {
    if (text === lastLogText) return;
    lastLogText = text;
    const logContainer = $('.log-container');
    logContainer.append(text + '\n');
    logContainer.scrollTop(logContainer[0].scrollHeight);
}

function updateProgress(percent) {
    const progressBar = $('.progress-bar');
    progressBar.css('width', percent + '%');
    progressBar.attr('aria-valuenow', percent);
    progressBar.text(percent + '%');
}

function disableControls() {
    $('#url, .convert-btn, .upload-btn').prop('disabled', true);
    $('.progress').fadeIn(500);
}

function enableControls() {
    $('#url, .convert-btn, .upload-btn').prop('disabled', false);
    $('.progress').fadeOut(500);
}

function query(url) {
    if (!url) {
        url = $("#url").val();
    }
    if (!url) return;
    
    $('.log-container').empty();
    updateProgress(0);
    disableControls();
    
    $.ajax({
        type: 'POST',
        url: '/api/convert', 
        // Added lang parameter
        data: { url: url, lang: currentScriptLang },
        success: function(response) {
            if (response.status === 200) {
                println(_S('taskSubmitSuccess') + response.message);
                localStorage.setItem("convertUid", response.message);
                startConversionMonitor(response.message);
            } else {
                println(response.message);
                enableControls();
                localStorage.removeItem("convertUid");
            }
        },
        error: function() {
            println(_S('taskSubmitFail'));
            enableControls();
            localStorage.removeItem("convertUid");
        }
    });
}

function startConversionMonitor(uuid) {
    const checkStatus = function() {
        $.ajax({
            type: 'POST',
            url: '/api/query', 
            // Added lang parameter
            data: { uuid: uuid, lang: currentScriptLang },
            success: function(response) {
                if (response.status === 200) { // Success
                    println(_S('conversionSuccessPrefix') + response.name); 
                    println(response.message); 
                    updateProgress(100);
                    enableControls();
                    localStorage.removeItem("convertUid");
                    
                    const downloadUrl = '/' + response.file;
                    downloadFile(downloadUrl, response.name);
                    
                    setTimeout(function() {
                        updateProgress(0);
                    }, 1000);
                } else if (response.status === 101) { // Pending / Working
                    println(response.message); 
                    if (response.progress) {
                        updateProgress(response.progress);
                    }
                    setTimeout(checkStatus, 1000);
                } else { // Error
                    println(response.message); 
                    enableControls();
                    localStorage.removeItem("convertUid");
                    
                    if (response.message.includes("服务器拒绝访问") || response.message.includes("Server access denied")) {
                        Swal.fire({
                            title: _S('fileConversionErrorTitle'),
                            icon: "warning",
                            html: _S('ddosWarningHtml')
                        });
                    }
                }
            },
            error: function() {
                println(_S('taskQueryFail'));
                enableControls();
                localStorage.removeItem("convertUid");
            }
        });
    };
    
    checkStatus();
}

function downloadFile(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function uploadFile(source) {
    const file = source.files ? source.files[0] : source; 

    if (!file) return;
    
    const MAX_FILE_SIZE_MB = 300;
    if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
        Swal.fire({
            title: _S('fileConversionErrorTitle'),
            icon: "warning",
            html: _S('fileTooLargeError')
        });
        return;
    }
    
    if (file.size === 0) {
        Swal.fire({
            title: _S('fileConversionErrorTitle'),
            icon: "warning",
            html: _S('fileEmptyError')
        });
        return;
    }
    
    $('.log-container').empty();
    updateProgress(0);
    disableControls();
    
    const formData = new FormData();
    formData.append("file", file);
    
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/upload', true);
    
    xhr.upload.onprogress = function(e) {
        if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100);
            updateProgress(percent);
            println(_S('uploadingFileProgress') + percent + "%");
        }
    };
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            const result = JSON.parse(xhr.responseText);
            if (result.url) {
                query(result.url); 
            } else {
                println(_S('fileUploadFail'));
                enableControls();
                localStorage.removeItem("convertUid");
                Swal.fire({
                    title: _S('fileConversionErrorTitle'),
                    icon: "warning",
                    html: _S('fileUploadFailTryAgain')
                });
            }
        } else {
            println(_S('fileUploadFail'));
            enableControls();
            localStorage.removeItem("convertUid");
            Swal.fire({
                title: _S('fileConversionErrorTitle'),
                icon: "warning",
                html: _S('fileUploadFailTryAgain')
            });
        }
        if (source.tagName === 'INPUT' && source.type === 'file') {
            $(source).val(''); 
        }
    };
    
    xhr.onerror = function() {
        println(_S('fileUploadFail'));
        enableControls();
        localStorage.removeItem("convertUid");
        if (source.tagName === 'INPUT' && source.type === 'file') {
            $(source).val('');
        }
    };
    
    xhr.send(formData);
}