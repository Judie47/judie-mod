@echo off
title Judie FiveM Auto Konverter
color 0A

echo ==============================================
echo       Judie's GTA 5 zu FiveM Konverter
echo ==============================================
echo.

if "%~1"=="" (
    color 0C
    echo [FEHLER] Du hast keine Datei ausgewaehlt!
    echo.
    echo BITTE SO MACHEN:
    echo Nimm eine heruntergeladene .zip Datei ^(z.B. ein Auto von gta5-mods^) 
    echo und ziehe sie mit der Maus per Drag ^& Drop direkt auf diese .bat Datei!
    echo.
    pause
    exit /b
)

echo Die Datei wird konvertiert... Bitte warten...
echo.

node "%~dp0convert.js" "%~1"

echo.
pause
