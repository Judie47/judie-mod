@echo off
title Judie Webserver
color 0B
echo Starte den Webserver...
node server.js
pause
